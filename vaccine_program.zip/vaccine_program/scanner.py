import yara
import sys
import os

def scan_file(file_path):
    rules = yara.compile(filepath='evil.yar') #규칙 파일 로드

    if not os.path.exists(file_path):
        print("[X] 파일이 존재하지 않습니다.")
        return

    matches = rules.match(filepath=file_path) #YARA를 통해 파일 검사 실행
    if matches:
        print("위험한 코드 탐지!")
        print(f"탐지된 규칙: {[m.rule for m in matches]}") #탐지된 규칙명 출력
    else:
        print("안전한 파일입니다.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("사용법: python scanner.py <파일경로>")
    else:
        scan_file(sys.argv[1]) #검사할 대상 파일이 존재하는지 확인한다.
